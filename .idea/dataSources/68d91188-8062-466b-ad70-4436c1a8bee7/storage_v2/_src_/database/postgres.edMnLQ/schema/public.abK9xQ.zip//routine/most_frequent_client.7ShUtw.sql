create function most_frequent_client(d date)
    returns TABLE(name character varying, id_cl integer, orders bigint)
    language plpgsql
as
$$
BEGIN
    IF d > CURRENT_DATE THEN
        RAISE EXCEPTION 'Несуществующая дата %', d
            USING HINT = 'Проверьте корректность даты';
    ELSE
        RETURN QUERY (
            WITH Last_orders AS (
                SELECT *
                FROM Orders
                WHERE date >= d
            ),
                 Count_orders AS (
                     SELECT id_client, COUNT(id_order) AS c
                     FROM Last_orders
                     GROUP BY id_client
                 ),
                 Numbered_counts AS (
                     SELECT id_client, row_number() OVER (ORDER BY c) AS r, c
                     FROM Count_orders
                 )
            SELECT Client.client_name, Client.id_client, Numbered_counts.c
            FROM Client
                     INNER JOIN Numbered_counts on Numbered_counts.id_client = Client.id_client
            WHERE r = 1
        );
    END IF;
END;
$$;

alter function most_frequent_client(date) owner to postgres;

