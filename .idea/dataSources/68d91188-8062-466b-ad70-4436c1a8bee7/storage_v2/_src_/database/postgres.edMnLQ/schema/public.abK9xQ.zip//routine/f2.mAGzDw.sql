create function f2(str text) returns text
    language plpgsql
as
$$
declare
        result text := '';
    begin
        for i in 1 .. length(str)
            loop
                result = result || str[length(str) - i];
            end loop;
        return result;
    end
$$;

alter function f2(text) owner to postgres;

