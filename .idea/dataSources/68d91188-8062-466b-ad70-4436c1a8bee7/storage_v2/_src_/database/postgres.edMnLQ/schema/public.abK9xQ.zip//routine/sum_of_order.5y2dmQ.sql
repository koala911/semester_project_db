create function sum_of_order(id_ord integer) returns bigint
    language plpgsql
as
$$
BEGIN
    IF (id_ord NOT IN (SELECT id_order FROM Orders))
    THEN RAISE EXCEPTION 'Несуществующий номер заказа %', id_ord
        USING HINT = 'Проверьте номер заказа';
    ELSE
        RETURN (SELECT SUM(price)
                FROM Orders
                         INNER JOIN DishInOrder ON Orders.id_order = DishInOrder.id_order
                         INNER JOIN Dishes on DishInOrder.id_dish = Dishes.id_dish
                WHERE Orders.id_order = id_ord);
    END IF;
END;
$$;

alter function sum_of_order(integer) owner to postgres;

