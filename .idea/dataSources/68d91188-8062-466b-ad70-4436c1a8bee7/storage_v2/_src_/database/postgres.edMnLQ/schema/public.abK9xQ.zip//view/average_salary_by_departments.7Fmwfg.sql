create view average_salary_by_departments(name, salary, average_salary, regarding_other) as
SELECT employees.emp_name                                                   AS name,
       employees.salary,
       round(avg(employees.salary) OVER (PARTITION BY employees.id_dep), 2) AS average_salary,
       round(employees.salary::numeric / avg(employees.salary) OVER (PARTITION BY employees.id_dep) * 100::numeric,
             2)                                                             AS regarding_other
FROM employees;

alter table average_salary_by_departments
    owner to postgres;

