create function triggerinsertintoemployeesupdate() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO EmployeeUpdate (id_emp, update_date, new_salary, new_dep) VALUES (NEW.id_emp, CURRENT_DATE, NEW.salary, NEW.id_dep);
    RETURN NEW;
END;
$$;

alter function triggerinsertintoemployeesupdate() owner to postgres;

