create function f1() returns text
    language sql
as
$$
select 'Hello, world';
$$;

alter function f1() owner to postgres;

