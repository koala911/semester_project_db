create view sum_of_clients_order(client_name, s) as
WITH sum_of_order AS (
    SELECT orders_1.id_order AS id_ord,
           sum(dishes.price) AS s
    FROM orders orders_1
             JOIN dishinorder ON orders_1.id_order = dishinorder.id_order
             JOIN dishes ON dishinorder.id_dish = dishes.id_dish
    GROUP BY orders_1.id_order
)
SELECT client.client_name,
       sum_of_order.s
FROM client
         JOIN orders ON client.id_client = orders.id_client
         JOIN sum_of_order ON sum_of_order.id_ord = orders.id_order;

alter table sum_of_clients_order
    owner to postgres;

